package com.example.NAGOYAMESHI.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.NAGOYAMESHI.entity.Store;

public interface StoreRepository extends JpaRepository<Store, Integer> {
    public Page<Store> findByNameLike(String keyword, Pageable pageable);

     public Page<Store> findByNameLikeOrAddressLike(String nameKeyword, String addressKeyword, Pageable pageable);    
     public Page<Store> findByAddressLike(String area, Pageable pageable);
     public Page<Store> findByPriceLessThanEqual(Integer upperPrice, Pageable pageable);    
}