package com.example.NAGOYAMESHI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NagoyameshiApplicationTests {

	@Test
	void contextLoads() {
	}

}
